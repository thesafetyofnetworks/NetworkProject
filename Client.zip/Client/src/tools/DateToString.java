package tools;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateToString {
	public  static String CurrentDate(){
		Date now = new Date();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddhhmmss");
		String str = df.format(now);
		return str;
	}

	public static  String dateToStr(Date date){
		String str=null;
		SimpleDateFormat df=new SimpleDateFormat("yyyyMMddhhmmss");
		str=df.format(date);
		return str;
	}
	public static Date strToDate(String str){
		Date date=null;
		SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");
		try {
			date=df.parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
	public static String lifetime(Date date){
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE,1);
		date = cal.getTime();
		String str=null;
		SimpleDateFormat df=new SimpleDateFormat("yyyyMMddhhmmss");
		str=df.format(date);
		return str;
	}
	public static void main(String[] args){
		System.out.println(DateToString.strToDate("2009-07-20"));
	}
}
