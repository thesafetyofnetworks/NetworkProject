package TGS;

import java.net.Socket;
import java.util.Scanner;

/**
 * 客户端
 * @author Administrator
 *
 */
public class tgs {
    private static String Ticket;
    private int port = 9011;
    private String ip="192.168.43.199";
    private static Socket socket;
    private static String username;
    private  static String Kctgs;
   public tgs(String Tick,String u,String key){
        try {
            init();
            Ticket=Tick;
            username=u;
            Kctgs=key;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void init() throws Exception {
        System.out.println("-----客户端已开启-----");
        socket = new Socket(ip,port);
    }

    public static  void hands(){
       try {
           Thread threadWriter = new Thread(new tgswriter(socket.getOutputStream(),socket.getInputStream(),Ticket,username,Kctgs));
           threadWriter.start();
       }catch (Exception L){

       }

    }
}