package TGS;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.util.Scanner;
import DES.DES_Method;
import UI.DateToString;
import UI.chatroom;
/**
 * 发送数据线程
 * @author Administrator
 *
 */
public class tgswriter implements Runnable{

    private String key="11111111111111111111111111111111111111111111111111111000";
    private OutputStream os;
    private InputStream is;
    private  String Ticket_tgs="";
    private String username="";
    String Kctgs="";
    public tgswriter(OutputStream os,InputStream is,String Tick,String user,String K) {
        this.is = is;
        this.os = os;
        Ticket_tgs=Tick;
        username=user;
        Kctgs=K;
    }

    @Override
    public void run() {
        String keys[]=DES_Method.Produce_keys("11111111111111111111111111111111111111111111111111111000");
        // int coode=M.hashCode();
        try {
            Scanner sc = new Scanner(System.in);
                System.out.println("client->server"+"：");
            //String message = sc.next();
            String IDv = "Chatroom";
            String TicketTgs_Encode;
            String AuthenticatorC_Encode;
            String TicketTgs_Decode;
            String Authenticator_Decode;
            String enkeysCAndTgs[]=DES_Method.Produce_keys("11111111111111111111111111111111111111111111111111111000");
            String keysCAndTgs = "11111111111111111111111111111111111111111111111111111000";
            InetAddress ip = InetAddress.getLocalHost();
            String ADc = ip.getHostAddress();
            String IDTgss = "Tgs";
            //String TS2 = "Time2";
            //String Lifetime2 = "Lifetime2";
          //  TicketTgs_Decode = keysCAndTgs + "@" + username + "@" + ADc + "@" + IDTgss + "@" + TS2 + "@" + Lifetime2;
           // String keyTgsAndAs[]=DES_Method.Produce_keys("11111111111111111111111111111111111111111111111111111000");
           // TicketTgs_Encode = DES_Method.DES_encry(TicketTgs_Decode,keyTgsAndAs);

            String TS3= DateToString.CurrentDate();
            Authenticator_Decode = username + "@" + ADc + "@" +TS3 ;
            String keyCAndTgs[]=DES_Method.Produce_keys(Kctgs);
            AuthenticatorC_Encode = DES_Method.DES_encry(Authenticator_Decode,keyCAndTgs);
            String IDv_TicketTge_AuthenticatorC = "00000110" + IDv  + "@" +  Ticket_tgs + "@" +AuthenticatorC_Encode;
            System.out.println("信息加密为："+IDv_TicketTge_AuthenticatorC);
            os.write(IDv_TicketTge_AuthenticatorC.getBytes());
            os.flush();
            read();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public void read() {
        String keys[] = DES_Method.Produce_keys(key);
        String dekeys[] = new String[16];
        for (int i = 0; i < 16; i++) {
            dekeys[i] = keys[15 - i];
        }
        try {
            //分支是否错误
            String message = "";
            byte[] b = new byte[20000];
            int length = is.read(b);
            message = new String(b, 0, length);
            System.out.println("获取到加密信息：" + message);
            int number = Integer.valueOf(message.substring(0,8),2);
            if(number!=11){
                System.out.println("TGS认证成功");
            String Message_head = message.substring(8, message.length());
            //使用client和Tgs的共享密钥解密
            String dekeysCAndTgs[] = DES_Method.Produce_keys(Kctgs);
            for (int i = 0; i < 16; i++) {
                dekeys[i] = dekeysCAndTgs[15 - i];
            }
            String Kcv_IDv_TS4_Ticket_tgs_Decode = DES_Method.DES_dencry(Message_head, dekeys);
            Tokenizer tokens_Kcv_IDv_TS4_Ticket_tgs_Decode = new Tokenizer(Kcv_IDv_TS4_Ticket_tgs_Decode, "@");//对原有消息进行分割
            String Kcv = tokens_Kcv_IDv_TS4_Ticket_tgs_Decode.nextToken();
            String IDv = tokens_Kcv_IDv_TS4_Ticket_tgs_Decode.nextToken();
            String TS4 = tokens_Kcv_IDv_TS4_Ticket_tgs_Decode.nextToken();
            String ticketv = tokens_Kcv_IDv_TS4_Ticket_tgs_Decode.nextToken();
            System.out.println("Kcv：" + Kcv);
            System.out.println("IDv：" + IDv);
            System.out.println("TS4：" + TS4);
            System.out.println("ticketv：" + ticketv);
            chatroom c=new chatroom(username,ticketv,Kcv);
            }
            else{
                System.out.println("TGS认证失败");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
        public class Tokenizer{
            String Tokens[];
            int TokenIndex = 0;
            //6.2.1 构造方法，把Message，按Delimiter进行分割
            public Tokenizer(String Message, String Delimiter) {
                Tokens = Message.split(Delimiter);
            }
            //6.2.2 获取下一项
            public String nextToken() {
                TokenIndex++;
                return Tokens[TokenIndex-1];
            }
        }


}