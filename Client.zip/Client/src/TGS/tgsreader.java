package TGS;

import java.io.IOException;
import java.io.InputStream;
import DES.DES_Method;

/**
 * 读取输入流线程
 * @author Administrator
 *
 */
public class tgsreader implements Runnable{

    private String key="11111111111111111111111111111111111111111111111111111000";
    //private static int HEAD_SIZE=5;//传输最大字节长度
    //private static int BUFFER_SIZE=10;//每次读取10个字节
    private InputStream is;
    private  String TicketV="";
    public tgsreader(InputStream is) {
        this.is = is;
    }
    @Override
    public void run() {
        String keys[]= DES_Method.Produce_keys(key);
        String dekeys[]=new String[16];
        for(int i=0;i<16;i++){
            dekeys[i]=keys[15-i];
        }
        try {
                String message="";
                byte[] b = new byte[20000];
                int length = is.read(b);
                message+= new String(b,0,length);
                System.out.println("获取到加密信息："+message);
                 String Message_head = message.substring(8,message.length());
                //使用client和Tgs的共享密钥解密
                 String dekeysCAndTgs[]=DES_Method.Produce_keys("11111111111111111111111111111111111111111111111111111000");
                 for(int i=0;i<16;i++){
                     dekeys[i]=dekeysCAndTgs[15-i];
                 }
                 String Kcv_IDv_TS4_TicketV_Decode = DES_Method.DES_dencry(Message_head,dekeys);
                 Tokenizer tokens_Kcv_IDv_TS4_TicketV_Decode = new Tokenizer(Kcv_IDv_TS4_TicketV_Decode, "@");//对原有消息进行分割
                 String Kcv = tokens_Kcv_IDv_TS4_TicketV_Decode.nextToken();
                 String IDv = tokens_Kcv_IDv_TS4_TicketV_Decode.nextToken();
                 String TS4 = tokens_Kcv_IDv_TS4_TicketV_Decode.nextToken();
                 TicketV = tokens_Kcv_IDv_TS4_TicketV_Decode.nextToken();
                 System.out.println("Kcv："+Kcv);
                 System.out.println("IDv："+IDv);
                 System.out.println("TS4："+TS4);
                 System.out.println("TicketV："+TicketV);
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public class Tokenizer{
        String Tokens[];
        int TokenIndex = 0;
        //6.2.1 构造方法，把Message，按Delimiter进行分割
        public Tokenizer(String Message, String Delimiter) {
            Tokens = Message.split(Delimiter);
        }
        //6.2.2 获取下一项
        public String nextToken() {
            TokenIndex++;
            return Tokens[TokenIndex-1];
        }
    }


}

