
package UI;
import DES.DES_Method;

import RSA.RSA;
import org.apache.log4j.Logger;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.Security;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import Bean.Select;
public class chatroom {
    public static Logger log = Logger.getLogger(chatroom.class.getClass());
    private String ServerIPAddress = "192.168.43.147";//199
    private   int ServerPort = 9002;
    public JPanel panel1;
    private JList list1;
    private JTextArea textArea3;
    private JButton exitButton;
    private JButton privateMessageButton;
    private JButton sendButton;
    private JTextArea textArea1;
    private JTextArea textArea2;
    private  String receiver="11111111";
    private JPanel listPanel;
    private JFrame chatroom;
    DefaultListModel<String> names;
    private Map<String,String[]> Keys=new HashMap<>();  //用于存储另外一个client信息
    private Map<String,String[]> Dekeys=new HashMap<>();
    private Socket socket;
    ClientThread cliendThread;
    private Map<String,Boolean> veryfiy=new HashMap<>();
    private String Kc_v="";         //会话密钥
    private String Kcv[]={""};
    private String Ticket_v="";
    private String clent2_e="65537";
    private String clent2_n="69914620778610837962071836844159775464865663982772265230294160094873927388627762795934182438872131818768926081338482268687136836415699567950498726460880111248861265451693127777755166701015411801942679073890971044389751422887312519283024730449764364384390251607411550199713795105253034808013140802435206192861078383636833337474004922953070697722956051524101365961344397116091025454474865041307310029230864025676588070665516529348077699460821344496436562379941924077360876510236722541140758607634590455875831160551024864711119996381199602338652460370655773030206251530011313984052573239382413330592631346974300986488033";
    private String clent1_e="65537";
    private String clent1_n="76248735052897542115199297142308769833733585919468551062880262643607186195666892580997565573625415412853652992591750936819802503660538896242060773809663595426364981060221322161004751070511223036040009424449151339810305969547787460033591981934413430174381172311828086180598876236368491714556428759286895283725727150267219854924917134114027984262125628410011931765842787345712954717251985925608795670875196229062940890123611249124678032347376464140538188934837993063034032233489709474806314419797860385075018458825529126300671373679702878097637264517797505906915965144095937462944093058220286387730274923913692748083809";
    private String clent3_e="65537";
    private String clent3_n="65207577476860353448098517274574653323425830990527467221204883095489876182667196046903796909532312427612721935377852977874576526043288357570227594734976760689737299959694641475707956529903649880967432187176136139077721112570720940954474492933198501174533155811607947142070760095467041869969136313184353471904481883462779188609705873982604919160027109789449257279434352994153130664907025209501790885102657933050157932938738449301661399980492976101087355017812087835976567832589527886065163201397163012745022893791988321707909512060352100727927177117713699390533701036369375110011809384974686884535838071264053808589349";
    private String clent4_e="65537";
    private String clent4_n="97846637462882128071567273197953938249691572342983120869287290885251417051351299525830689167776107438174651671046258142431305527260243620615509450131154143962222113226468841968458438593124740213138874579626506696481038452886801726913303661572825557904771383101673547605934094140976675673026591949744417276786191721912950163654001779529961536772722096744229407517566710862881517543216879150722353461930019616655419606535146428997115768348999346699454629931143339959052521958316815472914049975411346179460106861171019016896759562715573893065660937659643002172580128575299867031190685599871726709661153758876547227081613";
    //每个client有单独的clientD,clientN
    String ID;
    private String header="00010001";
    private Map<String,String> map=new HashMap<>();
    private String V_e="65537";         //应用服务器的公钥
    private String V_n="63718929442271952533922659964974670512090149845594539315941399589355689970449991568953306897314241973281030782923253808128220650970072943940781830691446209609971176934430693643458785400029638110812749871867552889455668043780497144567959782266220138138436189708409612736332102677705818352209082724559371222708377261301490747107220542349665376136509629788771633366449328510967133327832882202643290712782634315826970578578407451775165146357891890096690172664371421017982988978546098246551670703278409622714758569396591397546768678052883661472887556073799960978796135376937443662021273963924847864865257049430817697401453";
    //时间
    private String TS5="";
    private String temp_message="";
    BufferedReader input;//input为服务器传来的数据
    PrintStream output;//output为向服务器输出的数据
    public chatroom(String ID,String Tic,String kcv) {
        chatroom = new JFrame("chatroom");
        chatroom.setContentPane(panel1);
        chatroom.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        chatroom.pack();
        names = new DefaultListModel<String>();
        //chatroom.setBounds(300,200,500,200);
        list1.setModel(names);
        this.ID=ID;
        Ticket_v=Tic;
        Kc_v=kcv;
        ConnectServer();
        chatroom.setVisible(true);
        AddActionListener();
    }
    private void AddActionListener() {

        //4.2.3 点击发送
        sendButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String message = textArea1.getText().trim();
                try {
                    if (header.equals("00010001"))          //群聊
                    {
                        System.out.println("开始进行群聊");
                        BroadCast( header+ID +"@" +message+"@"+ RSA.signature(message,Constant.Client1D,Constant.Client1N));
                    }
                    else{
                        //私聊
                        if(veryfiy.get(receiver)==null)
                        {

                            String key=DES_Method.getrandomDESkey();
                            String keys[]=DES_Method.Produce_keys(key);
                            String dekeys[]=new String[16];
                            for(int i=0;i<16;i++){
                                dekeys[i]=keys[15-i];
                            }
                            temp_message=message;
                            Keys.put(receiver,keys);
                            Dekeys.put(receiver,dekeys);
                            sendpack14("00001110"+ID+"@"+receiver+"@",key);
                        }
                        else{
                            String keys[]=Keys.get(receiver);
                            SendMessage( header+ID+ "@"+receiver+"@",message,keys);
                        }
                        //   System.out.println("开始进行私聊");
                        // SendMessage( header+ID+ receiver+"@"+message+"@",Kcv);
                    }
                    textArea1.setText("");
                }catch (Exception L){

                }
            }
        });

        //4.2.4 检验目标发送者是谁
        list1.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int index = list1.getSelectedIndex();
                if(index<0) {
                    try {
                        ShowMessage("Client：检测到目标发送者下标为负数");
                    }catch (Exception L){

                    }
                    return;
                }
                if(index == 0) {
                    header="00010001";
                }else {
                    header="00010000";
                    String ToClientNickName = (String)names.getElementAt(index);
                    receiver = ToClientNickName;
                }
            }
        });
        list1.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int index = list1.getSelectedIndex();
                if(index<0) {
                    ShowMessage("Client：检测到目标发送者下标为负数");
                    return;
                }
                if(index == 0) {
                    receiver = "11111111";
                }else {
                    String ToClientNickName = (String)names.getElementAt(index);
                    receiver = ToClientNickName;
                }
            }
        });
    }
    //建立连接
    public void ConnectServer() {
        //3.1.1 获取基本信息//Integer.parseInt(ServerPortText.getText().trim());
        try {
            //3.1.2 socket相关
            socket = new Socket(ServerIPAddress, ServerPort);
            input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            output = new PrintStream(socket.getOutputStream());
            ThirdAuth_V();
            //3.1.2 在线列表添加所有人标签
            //3.1.3 向服务器发送本帐号登陆消息
            //ID="0004";
            //3.1.4 为客户端建立线程
            cliendThread = new ClientThread();

        } catch (UnknownHostException e) {
            ShowMessage("Client：主机地址异常"+e.getMessage());
            return;
        } catch (IOException e) {
            ShowMessage("Client：连接服务器异常"+e.getMessage());
            return;
        }catch (Exception e){

        }
    }

    public class ClientThread implements Runnable {
        //与服务器建立连接时，新建客户端线程，否则无法接收信息
        //与服务器断开连接时，向服务器告知，杀掉客户端进程
        //客户端调用readline时会产生死锁，故需要新建一个线程
        boolean isRuning = true;

        //5.1 构造函数
        public ClientThread() {
            //5.1.1 开始本线程
            new Thread(this).start();
        }

        @Override
        //5.2 run函数会在线程开始时自动调用
        public void run() {
            while (isRuning) {//循环用于重复接收消息，客户端断开连接之前不停止
                // TODO Auto-generated method stub
                String message;
                try {
                    //5.2.1 在服务器传来的消息中读取下一行
                    //readline会产生死锁，如果没有下一条消息则继续等待
                    //正是因为死锁，才要新建一个客户端线程
                    message = input.readLine();
                    int number = Integer.valueOf(message.substring(0,8),2);
                    message=message.substring(8);
                    try{
                        //5.2.2根据人为定义的传输协议对消息进行显示
                        //当用户通过应用服务器v之后，这时候向服务器发送上线通知，修改数据库登陆状态
                        switch (number) {
                            //发送一号报
                            case 1:{                //收到证书认证回复
                                //发送的是原文

                            }
                      /*  case 3:{
                            try{
                                message=RSA.RSA.RSA_dencry(message,AS_e,AS_n);
                            }catch (Exception e){
                                log.error(e.getMessage());
                            }
                            String code=message;
                            if (code.equals("0")){
                                log.info("注册成功");
                            }
                            else{
                                    log.error("注册失败");
                                }
                            //send4号包
                            break;
                        }*/
                            case 5:{

                            }
                            case 7:{
                             }
                            case 9:{
                                //v-C
                                try{
                                    String keys[]=DES_Method.Produce_keys(Kc_v);
                                    String dekeys[]=new String[16];
                                    for(int i=0;i<16;i++){
                                        dekeys[i]=keys[15-i];
                                    }
                                    message=DES_Method.DES_dencry(message,dekeys);
                                }catch (Exception e){
                                    log.error(e.getMessage());
                                }
                                String ts_add1=message;
                                if(ts_add1.substring(0,14).equals(TS5.substring(0,13)+String.valueOf((Integer.valueOf(TS5.substring(13))+1)).substring(0,1))) {
                                    log.info("服务器验证成功");
                                    textArea2.setText("Client登陆成功");
                                    SendLoginMessage("00001101",ID);
                                }else
                                    log.error("服务器验证失败");
                                //此时登陆进入聊天室
                                //server此时发送
                                break;
                            }
                            case 10:{                //接收c-c会话密钥
                                try{
                                    String dekeys[]=DES_Method.Produce_keys(Kc_v);
                                    message=DES_Method.DES_dencry(message,dekeys);
                                }catch (Exception e){
                                    log.error(e.getMessage());
                                }
                                Tokenizer tokens = new Tokenizer(message, "@");
                                String ID_my = tokens.nextToken();
                                String ID_send = tokens.nextToken();
                                String sessionkey= tokens.nextToken();
                                String keys[]=DES_Method.Produce_keys(sessionkey);
                                String dekeys[]=new String[16];
                                for(int i=0;i<16;i++){
                                    dekeys[i]=keys[15-i];
                                }
                                Keys.put(ID_send,keys);
                                Dekeys.put(ID_send,dekeys);
                                break;
                                //请求数字证书认证
                            }
                            case 14:{
                                Tokenizer tokens = new Tokenizer(message, "@");
                                String ID_send = tokens.nextToken();
                                String ID_my = tokens.nextToken();
                                String sessionkey= tokens.nextToken();
                                String dekeys[]=new String[16];
                                for(int i=0;i<16;i++){
                                    dekeys[i]=Kcv[15-i];
                                }
                                sessionkey=DES_Method.Encry(sessionkey,dekeys);
                                System.out.println("收到来自"+ID_send+"的信息");
                                String sess[]=DES_Method.Produce_keys(sessionkey);
                                Keys.put(ID_send,sess);
                                for(int i=0;i<16;i++){
                                    dekeys[i]=sess[15-i];
                                }
                                Dekeys.put(ID_send,dekeys);
                                sendpack15("00001111"+ID+"@"+ID_send+"@","1");
                                System.out.println("发送私聊请求确认");
                                break;
                            }
                            case 15:{
                                System.out.println("收到转发确认回复消息"+message);
                                Tokenizer tokens = new Tokenizer(message, "@");
                                String ID_send = tokens.nextToken();
                                String ID_rec = tokens.nextToken();
                                message = tokens.nextToken();
                                String dekeys[]=new String[16];
                                for(int i=0;i<16;i++){
                                    dekeys[i]=Kcv[15-i];
                                }
                                try {                               //信息解密过程
                                    message = Message(message,dekeys);     //DES解密
                                }catch (Exception L){
                                    ShowMessage("解密错误");
                                }
                                if (message.substring(0,1).equals("1")) {
                                    System.out.println("收到私聊请求允许包");
                                    System.out.println("开始私聊啦");
                                    veryfiy.put(ID_send, true);
                                String keys[]=Keys.get(ID_send);
                                SendMessage( header+ID+"@"+ receiver+"@",temp_message,keys);
                                }
                                break;
                            }
                            case 16:{                   //si聊
                                Tokenizer tokens = new Tokenizer(message,"@");
                                System.out.println("客户端"+ID+"收到私聊消息"+message);
                                String send = tokens.nextToken();       //发送端
                                String ToClientNickName=tokens.nextToken();
                                message=tokens.nextToken();
                                String dekeys[]=Dekeys.get(send);  //得到该ID的key
                                try {                               //信息解密过程
                                    message = Message(message,dekeys);     //DES解密
                                }catch (Exception L){
                                    ShowMessage("解密错误");
                                }
                                ShowMessage("来自" + send + "对您的私聊消息：" + message);
                                break;
                                //注册使用
                            }
                            case 17:{                       //群聊信息
                                Tokenizer tokens = new Tokenizer(message, "@");
                                String sender = tokens.nextToken();
                                String content = tokens.nextToken();
                                String signa = tokens.nextToken();
                                String keyn=Select.select_Pk(sender);
                                Tokenizer tokens1 = new Tokenizer(keyn, "@");
                               String e= tokens1.nextToken();
                                keyn=tokens1.nextToken();
                                if(!(RSA.verifysign(signa,content,e,keyn))){
                                    //logger.e("信息被篡改");
                                    ShowMessage("信息被篡改");
                                }
                                else {
                                    Settext3("信息签名值为"+signa);
                                    ShowMessage("信息已经过签名认证，收到来自" + sender + "对全体的消息：" + content);
                                }
                                break;
                            }
                            case 18:{                //上线
                                Tokenizer tokens = new Tokenizer(message, "@");
                                String ShowMessageinClientNickName = tokens.nextToken();
                                String sign = tokens.nextToken();
                                if(!RSA.verifysign(sign,ShowMessageinClientNickName,V_e,V_n)) {
                                    System.out.println("收到上线消息，数字签名不符合");
                                    log.error("数字签名不符合");
                                }else {
                                    System.out.println("收到上线消息，数字签名符合");
                                    names.addElement(ShowMessageinClientNickName);
                                    ShowMessage("上线通知：用户" + ShowMessageinClientNickName + "已上线");
                                }
                                break;
                                //请求数字证书认证
                            }
                    /*    case "ShowMessageIN": {//其他用户上线
                            String ShowMessageinClientNickName = tokens.nextToken();
                            ShowMessage("上线通知：用户" + ShowMessageinClientNickName + "已上线");
                            names.addElement(ShowMessageinClientNickName);
                            break;
                        }

                        case "MESSAGE": {//聊天消息
                            String ToClientNickName = tokens.nextToken();
                            String FromClientNickName = tokens.nextToken();
                            String content = tokens.nextToken();
                            if ("ALL".equals(ToClientNickName)) {
                                ShowMessage("来自" + FromClientNickName + "对全体的消息：" + content);
                            } else {
                                ShowMessage("来自" + FromClientNickName + "对您的私聊消息：" + content);
                            }
                            break;
                        }

                        case "ShowMessageOUT": {//其他用户下线的消息

                            break;
                        }*/
                            default: {
                                ShowMessage("客户端接收消息格式错误");
                                break;
                            }
                        }
                    }catch (Exception e){

                    }
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    ShowMessage("Client：客户端接收消息失败" + e.getMessage());
                    break;
                }
            }
        }
    }
    public class Tokenizer{
        String Tokens[];
        int TokenIndex = 0;
        //6.2.1 构造方法，把Message，按Delimiter进行分割
        public Tokenizer(String Message, String Delimiter) {
            Tokens = Message.split(Delimiter);
        }
        //6.2.2 获取下一项
        public String nextToken() {
            TokenIndex++;
            return Tokens[TokenIndex-1];
        }
    }
    private void BroadCast(String message){
        output.println(message);
        output.flush();
    }
    //发送消息
    public void SendMessage(String head,String message,String key[]) throws Exception {
        message=DataCry(message,key);
        output.println(head+message);
        output.flush();
    }
    public void sendpack14(String hea,String key){
        try{
            key=DES_Method.Encry(key,Kcv);
            System.out.println("14包内容"+hea+key);
            output.println(hea+key);
            output.flush();
        }catch (Exception e){

        }
    }
    public void sendpack15(String hea,String yes){
        try{
            yes=DataCry(yes,Kcv);
            output.println(hea+yes);
            output.flush();
        }catch (Exception e){

        }
    }
    public void SendLoginMessage(String toubu,String message) throws Exception {
        //  message=DataCry(message,Kcv);
        output.println(toubu+message);
        output.flush();
    }
    private void ShowMessage(String message){
        //JLabel不支持\n换行，故添加html标签进行换行，没有</html>结束标签不影响显示
        textArea2.setText(textArea2.getText()+message+"\n");
    }
    private void Settext3(String message){
        textArea3.setText(textArea3.getText()+message+"\n");
    }
    private String DataCry(String message,String keys[]) throws Exception{
        //String keys[]=DES_Method.Produce_keys("11111111111111111111111111111111111111111111111111111000");
        String C= DES_Method.DES_encry(message,keys);
        message=("发送消息"+message+"加密为："+C);
        textArea3.setText(textArea3.getText()+message+"\n");
        return C;
    }
    private String  Message(String message,String []dekeys) throws Exception{           //接收消息进行解密
      //  String keys[]= DES_Method.Produce_keys("11111111111111111111111111111111111111111111111111111000");
        textArea3.setText(textArea3.getText()+"\n"+"收到加密信息为"+message);
       // for(int i=0;i<16;i++){
       //     dekeys[i]=keys[15-i];
     //   }
        message=DES_Method.DES_dencry(message,dekeys);
        textArea3.setText(textArea3.getText()+"\n"+"信息解密为"+message);
       // textArea2.setText(textArea2.getText()+"\n"+message);
        return message;
    }
    private void ThirdAuth_V() {
        try{
            String IDv = "client_to_v";
            String AuthenticatorC_Encode;
            String TicketV_Decode;
            String Authenticator_Decode;
            InetAddress ip = InetAddress.getLocalHost();
            String ADc = ip.getHostAddress();
            TS5=DateToString.CurrentDate();
            Authenticator_Decode = ID + "@" + ADc + "@" + TS5;
            Kcv = DES_Method.Produce_keys(Kc_v);
            AuthenticatorC_Encode = DES_Method.DES_encry(Authenticator_Decode, Kcv);
            String TicketV_AuthenticatorC = "00001000" + Ticket_v + "@" + AuthenticatorC_Encode;
            System.out.println("发送12"+TicketV_AuthenticatorC);
            output.println(TicketV_AuthenticatorC);
            output.flush();
        }catch (Exception e){

        }
    }
}
