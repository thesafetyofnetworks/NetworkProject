package UI;

import DES.DES_Method;

import javax.swing.*;
import java.io.IOException;
import java.io.InputStream;

/**
 * 读取输入流线程
 * @author Administrator
 *
 */
public class ThreadReader implements Runnable{
    private JTextArea textArea2;
    private JTextArea textArea3;
    DefaultListModel<String> names;
    private String key="11111111111111111111111111111111111111111111111111111000";
    //private static int HEAD_SIZE=5;//传输最大字节长度
    //private static int BUFFER_SIZE=10;//每次读取10个字节
    private InputStream is;
    public ThreadReader(InputStream is,JTextArea a,JTextArea b, DefaultListModel<String> names1) {
        this.is = is;
        textArea2=a;
        textArea3=b;
        names=names1;
    }

    @Override
    public void run() {
        names.addElement("ALL");
        String keys[]= DES_Method.Produce_keys(key);
        String dekeys[]=new String[16];
        for(int i=0;i<16;i++){
            dekeys[i]=keys[15-i];
        }
        try {
            while (true) {
                byte[] b = new byte[1024];
                int length = is.read(b);
                String message = new String(b, 0, length);
                Tokenizer tokens = new Tokenizer(message, "@");//对原有消息进行分割
                String MessageType = tokens.nextToken();

                //5.2.2根据人为定义的传输协议对消息进行显示
                switch (MessageType) {
                    case "LOGIN": {//其他用户上线
                        String LoginClientNickName = tokens.nextToken();
                       String temp="上线通知：用户" + LoginClientNickName + "已上线";
                       textArea2.setText(temp);
                        textArea3.setText(message);
                        names.addElement(LoginClientNickName);
                        break;
                    }
                    case "MESSAGE": {//聊天消息
                        String ToClientNickName = tokens.nextToken();
                        String FromClientNickName = tokens.nextToken();
                        String content = tokens.nextToken();
                        if ("ALL".equals(ToClientNickName)) {
                            textArea2.setText(content);
                            textArea3.setText(content);
                           // MessageTotal("来自" + FromClientNickName + "对全体的消息：" + content);
                        } else {
                            textArea2.setText(content);
                            textArea3.setText(content);
                           // Message("来自" + FromClientNickName + "对您的私聊消息：" + content);
                        }
                        break;
                    }

                    case "LOGOUT": {//其他用户下线的消息

                        break;
                    }
                    default: {
                      //  Error("客户端接收消息格式错误");
                        break;
                    }
                }
              //  textArea3.setText("231231");
                System.out.println("客户端接收到" + message);
            }
                // TODO Auto-generated catch block
                //    Error("Client：客户端接收消息失败"+ e.getMessage());


            //    System.out.println("获取到加密信息："+message);
            //   String M=DES_Method.DES_dencry(message,dekeys);
           //     System.out.println("信息解密为"+M);

                    }catch (IOException e) {
            e.printStackTrace();
        }
        }

    public class Tokenizer{
    String Tokens[];
    int TokenIndex = 0;
    //6.2.1 构造方法，把Message，按Delimiter进行分割
    public Tokenizer(String Message, String Delimiter) {
        Tokens = Message.split(Delimiter);
    }
    //6.2.2 获取下一项
    public String nextToken() {
        TokenIndex++;
        return Tokens[TokenIndex-1];
    }
}

}