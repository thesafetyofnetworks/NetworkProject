package UI;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class privatechat {
    private JPanel panel1;
    private JButton sendButton;
    private JTextArea textArea1;
    private JTextArea textArea2;
    private JTextArea textArea3;

    public privatechat() {
        sendButton.addActionListener(new ActionListener() {
            @Override
            //点击send之后的操作
            public void actionPerformed(ActionEvent e) {

            }
        });
    }
}
