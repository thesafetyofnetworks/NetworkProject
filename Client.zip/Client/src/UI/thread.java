package UI;
import java.io.IOException;
import java.io.InputStream;
import DES.DES_Method;

/**
 * 读取输入流线程
 * @author Administrator
 *
 */
public class thread implements Runnable{
    private InputStream is;
    public thread(InputStream is) {
        this.is = is;
    }
    private String KDC_e="65537";        //自己填
    private String KDC_n="45421423778838733039603238611637851960849313479380412817338595732002346548313122322183651483558346490458010935351467441722156510037349021099869477696473313479776908254911352756062607253532803417728009105621989299905261498976581455825420109436469793488925622269844492647717678624151848542224359291144168601746540784842276119577880806584759565344814015078909199009009840336436590036514262532888868932075410115450089611663581485240510992301112029487130213164506017993687266925706445237244532923273131828107873102643984030040761778339242180089245976603016779551482130656966628844100743596994856519735654595835535365195633";
    @Override
    public void run() {
        try {
                String message="";
                byte[] b = new byte[10240];
                int length = is.read(b);
                message= new String(b,0,length);
                System.out.println("收到认证信息为"+message);
                int number = Integer.valueOf(message.substring(0,8),2);
                System.out.println(number);
                message=message.substring(8);
                if(number==1){
                Tokenizer tokens = new Tokenizer(message, "@");
                String id = tokens.nextToken();
                String AS_e= tokens.nextToken();
                String AS_n= tokens.nextToken();
                String sign_ = tokens.nextToken();
                String mess=id+"@"+AS_e+"@"+AS_n;
                if(!RSA.RSA.verifysign(sign_,mess,KDC_e,KDC_n))
               System.out.println("AS数字证书不符合");
                else
                    System.out.println("AS数字证书验证成功");
        }
                else {
                    System.out.println("本地数字证书验证失败");
                }
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }

}
