package UI;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import DES.DES_Method;
import TGS.tgs;
import AS.Client;
import UI.chatroom;
public class start {
    private JPanel Panel_Root;
    private JTextField TextField_Account;
    private JPasswordField TextField_Password;
    private JButton Button_Sign_In;
    private JButton Button_Register;
    private JLabel passwordLabel;
    private JLabel accountLabel;
    private JTextField textField1;
    private String username;
    private String password;
    private static int port = 9000;
    public static String ip="192.168.43.147";
    private static Socket socket;
    private String ID="";
    //显示注册界面
    private void newRegister( )
    {
        JFrame register = new JFrame("register");
        register.setContentPane(new register().Panel_Root);
        register.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        register.pack();
        //register.setBounds(300,200,400,100);
        register.setVisible(true);
    }

    //点击注册sign in之后的操作
    public start() {
        Button_Sign_In.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //连接数据库，判断账号密码
                //与TGS通信
             //AS.Client=new Client();
                username=TextField_Account.getText();
                password=TextField_Password.getText();
                try{
                    Client client=new Client(username,password,"1",textField1);
                    client.hands();
                }
                catch (Exception L){

                }
            //显示聊天室界面new UI.chatroom();

                //chatroom client = new chatroom("001","2011111","");
            }
        });

        //点击Regiter按钮之后的操作
        Button_Register.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //显示注册界面
                //认证AS证书
            newRegister();
                //注册结束，返回登陆界面
            }
        });
    }
    private void write(OutputStream os){

    }
    public static void main(String[] args) {
        JFrame start = new JFrame("start");
        start.setContentPane(new start().Panel_Root);
        start.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        start.pack();
        start.setVisible(true);
      /*  try {
            socket = new Socket(ip, port);
            Thread threadWriter = new Thread(new thwrite(socket.getOutputStream()));
            Thread threadReader = new Thread(new thread(socket.getInputStream()));
            threadWriter.start();
            threadReader.start();
            //传输注册信息
        }catch (Exception L){

        }*/
    }


}
