package UI;

import DES.DES_Method;

import javax.swing.*;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Scanner;

/**
 * 发送数据线程
 * @author Administrator
 *
 */
public class ThreadWriter implements Runnable{

    private String key="11111111111111111111111111111111111111111111111111111000";
    private OutputStream os;
    private JTextArea textArea1;
    JTextArea textArea3;
    private String rec;
    private String send;
    public ThreadWriter(OutputStream os,  JTextArea textArea,JTextArea textArea3,String r,String sen) {
        this.os = os;
        rec=r;
        send=sen;
        textArea1=textArea;
        this.textArea3=textArea3;
    }
    @Override
    public void run() {
      //  String keys[]=DES_Method.Produce_keys("11111111111111111111111111111111111111111111111111111000");
        // int coode=M.hashCode();
        try {
            Scanner sc = new Scanner(System.in);
            while(true){

                System.out.println("client->server"+"：");
               // String message = sc.next();
                String message =textArea1.getText();
                String C="MESSAGE"+"@"+rec+"@"+send+"@"+message;
               // String C=DES_Method.DES_encry(message,keys);
               // System.out.println("信息加密为："+C);
                textArea3.setText(message);
                os.write(C.getBytes());
                os.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}