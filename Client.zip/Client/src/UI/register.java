package UI;
import AS.Client;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.Socket;

public class register {
    public JPanel Panel_Root;
    private JTextField textField1;
    private JPasswordField passwordField1;
    private JPasswordField passwordField2;
    private JButton exitButton;
    private JButton registerButton;
    private JTextField textField2;
    private Socket socket;
    public register() {
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //认证AS证书
            }
        });

        //点击Regiter按钮之后的操作
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //显示注册界面
                String account = textField1.getText();
                String passwd = passwordField1.getText();
                String passwd1=passwordField2.getText();
                if (!passwd.equals(passwd1)){
                        textField2.setText("密码不一致请重新输入");
                }
                else{
                    textField2.setText(" ");
                //认证AS证书
                account=textField1.getText();
                passwd=passwordField1.getText();
                try{
                    Client client=new Client(account,passwd,"0",textField2);
                    client.hands();
                }
                catch (Exception L){

                }
            }}
        });
    }
}
