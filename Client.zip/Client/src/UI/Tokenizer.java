package UI;

public class Tokenizer{
    String Tokens[];
    int TokenIndex = 0;
    //6.2.1 构造方法，把Message，按Delimiter进行分割
    public Tokenizer(String Message, String Delimiter) {
        Tokens = Message.split(Delimiter);
    }
    //6.2.2 获取下一项
    public String nextToken() {
        TokenIndex++;
        return Tokens[TokenIndex-1];
    }
}