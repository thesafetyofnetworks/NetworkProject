package RSA;

import com.mysql.cj.protocol.Message;
import com.sun.security.auth.UnixNumericGroupPrincipal;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.util.Random;

public class RSA {
    private static final int ORDER =2048/2;// 随机数的数量级
    private static final BigInteger two =new BigInteger("2");
    private static final BigInteger one =new BigInteger("1");
    public static BigInteger[] getkey(){
        BigInteger[]keys=new BigInteger[3];
        Random rnd = new Random();
        long startTime = System.currentTimeMillis();
        BigInteger temp=BigInteger.probablePrime(ORDER,rnd);
        BigInteger p= temp.multiply(two).add(one);                       //得到p
        while(!MR.isPrime(p)){
            temp=BigInteger.probablePrime(ORDER,rnd);
            p= temp.multiply(two).add(one);
        }
        temp=BigInteger.probablePrime(ORDER,rnd);
        BigInteger q= temp.multiply(two).add(one);                        //得到q
        while(!MR.isPrime(q)){
            temp=BigInteger.probablePrime(ORDER,rnd);
            q= temp.multiply(two).add(one);
        }
        BigInteger n=p.multiply(q);                                          //得到n
        System.out.println("p:"+p);
        System.out.println("q:"+q);
        BigInteger Fn=(p.subtract(one)).multiply(q.subtract(one));             //得到欧拉函数值Fn
        System.out.println("Fn : "+Fn.toString());
        BigInteger e=BigInteger.valueOf(65537);
        if(Fn.gcd(e)!=BigInteger.valueOf(1))
        MR.getgcd(Fn);                                      //获取到e
        BigInteger d=MR.Egcd(Fn,e);                          //获取到d
        if(d.compareTo(BigInteger.ZERO)<0){
            d=d.add(Fn);                          //获取到d
        }
        System.out.println("e :"+e);
        System.out.println("d :"+d);
        System.out.println("n :"+n.toString());
        System.out.println("生成参数正确性验证：");
        System.out.println("gcd(Fn,e)="+(Fn.gcd(e)));
        System.out.println("d*e mod fn="+(d.multiply(e)).mod(Fn));
        keys[0]=e;
        keys[1]=d;
        keys[2]=n;
        return keys;
    }
    private static String charTobyte(String a){
        int value=0;
        String c=""; String bs="";
        int size=a.length();
        for(int i=0;i<size;i++){
            value = 1 << 8 | a.charAt(i);              //10进制转为长度为4的2进制字符串
            bs = Integer.toBinaryString(value);
            c += bs.substring(1);
        }
        return c;
    }
    private static String byteTochar(String a){
        int value=0;
        String c="";
        int b=0;
        int size=a.length()/8;
        for(int i=0;i<size;i++){
            b=(Integer.parseInt(a.substring(i*8,(i+1)*8),2));
            c+= String.valueOf((char)b);
        }
        return c;
    }
    public static String RSA_encry(String Message,String Pk,String n) throws UnsupportedEncodingException {
      //  final Base64.Encoder encoder = Base64.getEncoder();
     //   byte[] textByte = Message.getBytes("UTF-8");
     //   Message= encoder.encodeToString(textByte);
        Message="11"+charTobyte(Message);
        BigInteger M=new BigInteger(Message);
           BigInteger P=new BigInteger(Pk);
            BigInteger N=new BigInteger(n);
            BigInteger C=M.modPow(P,N);
            return C.toString();
            }
    public static String RSA_dencry(String Message,String Pk,String n) throws UnsupportedEncodingException {
      //  final Base64.Decoder decoder = Base64.getDecoder();
        BigInteger C=new BigInteger(Message);
        BigInteger D=new BigInteger(Pk);
        BigInteger N=new BigInteger(n);
        BigInteger M=C.modPow(D,N);
        String Mo="";
        try {
             Mo = byteTochar(M.toString().substring(2));
        }catch (Exception L){
            return "";
        }
        return Mo;//new String(decoder.decode(Mo), "UTF-8");
    }
    public static String signature(String Message,String d,String n) throws UnsupportedEncodingException {          //生成签名
        String H= Security.md5digest(Message);   //先获取摘要信息
        String sign=RSA_encry(H,d,n);
        return sign;
    }
    public static boolean verifysign(String sign,String Message, String e, String n) throws UnsupportedEncodingException {          //验证签名
        String H = Security.md5digest(Message);   //先获取摘要信息
        String sign1=RSA_dencry(sign,e,n);         //将解密后的签名与摘要比较
        if(sign1.equals(H))
            return true;
        else
            return false;
    }
    public static boolean verifycert (String ID,String Pk,String sign) throws UnsupportedEncodingException {
        String e="";
        String n="";
        String get=Security.md5digest(ID+"@"+Pk);
        String C=RSA_dencry(sign,e,n);
        if(get.equals(C))
        return true;
        else
            return false;
    }
    public static void main(String[] args) throws UnsupportedEncodingException{
      //  MR.Square_and_Mutiply(BigInteger.valueOf(5),3,BigInteger.valueOf(33));
         long startTime = System.currentTimeMillis();
      //  BigInteger []keys=getkey();
       String keys[]={"65537",
        "33128523683239871206998104973317199806652687555341009394216776416218505043095766467802593052994323240976744780960375722329662346152330488252037185618679896613109178244118019771118492251993042149738297988139998604383348332256291767832752204572428645326619234089118616179576499355088856070896201750411084717998445641388765178359509326082428085236695704622993009341663757880293718984591408936642585904671874566356953585654786901876430391921341611788399950360507457097264955673067893275870789062219328449191410267100575406190743531463882565983021896240098036635843553431121867118531960068120301335153014334995449567352673",
                "45421423778838733039603238611637851960849313479380412817338595732002346548313122322183651483558346490458010935351467441722156510037349021099869477696473313479776908254911352756062607253532803417728009105621989299905261498976581455825420109436469793488925622269844492647717678624151848542224359291144168601746540784842276119577880806584759565344814015078909199009009840336436590036514262532888868932075410115450089611663581485240510992301112029487130213164506017993687266925706445237244532923273131828107873102643984030040761778339242180089245976603016779551482130656966628844100743596994856519735654595835535365195633"
        };
        String M="zn@123456";
    //    String H= Security.md5digest(M);
   //     System.out.println(H);
        String sign=signature(M,keys[1].toString(),keys[2].toString());
        System.out.println(verifysign(sign,M,keys[0].toString(),keys[2].toString()));
        //String M="0011nznxnzyqwuyeuqweuywequweyqwyeuqwyeuqyweq13130011yeuqwyeuqyweq131313130011";
     //   BigInteger a=new BigInteger(keys[2]);
       // String v=a.toString(2);

       String C=RSA_encry(M,keys[0].toString(),keys[2].toString());
      //  BigInteger M=new BigInteger("65546848646848444615313213213215165169999999999999999999999785653657520563467735121515155");
       System.out.println("原始密文加密为"+C);
        System.out.println("    密文解密为"+RSA_dencry(C,keys[1].toString(),keys[2].toString()));//BigInteger.valueOf(1019),BigInteger.valueOf(3337)));
        long endTime1 = System.currentTimeMillis();
        System.out.println("运行时间:" + (endTime1 - startTime) + "ms");
    }
}
