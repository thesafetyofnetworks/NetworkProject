package AS;

import DES.DES_Method;
import RSA.RSA;
import tools.DateToString;
import tools.Tokenizer;
import TGS.tgs;

import javax.swing.*;
import java.net.InetAddress;

public class listener {
    String As_req;        // AS请求报文标识
    String ID_C;          // Client用户标识
    String ID_TGS;        // TGS编号
    String timestamp;     // 时间戳
    String c1_e = "65537";
    String c1_d = "60201329730947867909865761803738727532183509617727096238730431820663293139884152306500725285589415065118931602738415863936461247072812680579660232845678518725938471092361446112867995779369405446951405277304375954455414072787596538321531097139238728213729334270766627879349195904216720864214227836497567932024279623822294598448634555551200673809895100164033129890410559145169337501011237918165284192744447873833738201841368380273018264307467857470975348598013170656924365928830698363390433396257804064918502143497644620964086019862840120852331626228847711265024313012960648515046590268288125670430799088941043449678465";
    String c1_n = "76248735052897542115199297142308769833733585919468551062880262643607186195666892580997565573625415412853652992591750936819802503660538896242060773809663595426364981060221322161004751070511223036040009424449151339810305969547787460033591981934413430174381172311828086180598876236368491714556428759286895283725727150267219854924917134114027984262125628410011931765842787345712954717251985925608795670875196229062940890123611249124678032347376464140538188934837993063034032233489709474806314419797860385075018458825529126300671373679702878097637264517797505906915965144095937462944093058220286387730274923913692748083809";
    String KDC_e = "65537";
    String KDC_d = "33128523683239871206998104973317199806652687555341009394216776416218505043095766467802593052994323240976744780960375722329662346152330488252037185618679896613109178244118019771118492251993042149738297988139998604383348332256291767832752204572428645326619234089118616179576499355088856070896201750411084717998445641388765178359509326082428085236695704622993009341663757880293718984591408936642585904671874566356953585654786901876430391921341611788399950360507457097264955673067893275870789062219328449191410267100575406190743531463882565983021896240098036635843553431121867118531960068120301335153014334995449567352673";
    String KDC_n = "45421423778838733039603238611637851960849313479380412817338595732002346548313122322183651483558346490458010935351467441722156510037349021099869477696473313479776908254911352756062607253532803417728009105621989299905261498976581455825420109436469793488925622269844492647717678624151848542224359291144168601746540784842276119577880806584759565344814015078909199009009840336436590036514262532888868932075410115450089611663581485240510992301112029487130213164506017993687266925706445237244532923273131828107873102643984030040761778339242180089245976603016779551482130656966628844100743596994856519735654595835535365195633";
    String[] keys ={};      //自己的DES
    String password = "";
    private String ktgs = "0100000101001000010010010100100001010001010001000100001001010111";
    String username="";
    String Kctgs="";
    String type = "";
    String tickettgs="";
    public listener(String us, String pa, String ty){
        username=us;
        password=pa;
        type = ty;
    }
    public String Client(String as_req, String address)   //得到客户端用户标识IDc，客户端所请求的票据授权服务端的标识IDtgs和时间戳S1.
    {
        int number = Integer.valueOf(as_req.substring(0, 8), 2);
        String msg = as_req.substring(8, as_req.length());
        String result = "";
        switch (number) {
            case 0: {

                //请求数字证书认证
                //    result = As_Process_1(msg,address);
                break;
            }
            case 1: {
                //回复数字证书认证
                result = C_Process_2(msg, address);
                break;
            }
            case 2: {
                //注册使用

                break;
            }
            case 3: {
                //AS返回注册信息
                result = C_Process_3(msg,address);
                break;
            }
            case 4: {
                //C-AS

                break;
            }
            case 5: {
                //AS-C
                result = C_Process_4(msg, address);
                tgs t=new tgs(tickettgs,username,Kctgs);    //传递票据ticket tgs
                tgs.hands();
                System.out.println("要进入TGS咯");
                return null;
            }
        }
        return result;
    }
    public String C_Process_1(){
    String sendmessage =username+ "@"+c1_e+"@"+c1_n;
    String sign="";
    try {
        sign = RSA.signature(sendmessage,KDC_d,KDC_n);
    }catch (Exception e){
        e.printStackTrace();
    }

    return "00000000"+sendmessage+"@"+sign;
    };      //发起数字认证请求
    public String C_Process_2(String msg,String address){
        Tokenizer tokenizer = new Tokenizer(msg,"@");
        String As = tokenizer.nextToken();
        String as_e = tokenizer.nextToken();
        String as_n = tokenizer.nextToken();
   /*     String signa=tokenizer.nextToken();
     //   String result1 = Store(As,as_e+"@"+as_n);
        if(!(RSA.verifysign(signa,content,"65537",keyn))){
            //logger.e("信息被篡改");
            ShowMessage("信息被篡改");
        }
        else {
            Settext3("信息签名值为"+signa);
            ShowMessage("信息已经过签名认证，收到来自" + sender + "对全体的消息：" + content);
        }*/

        String res = "client1"+"@"+username+"@"+password+"@"+type;

        return "00000010"+res;

    };      //确认数字认证成功，并发送注册使用的包

    public String C_Process_3(String msg,String address){
      //  Tokenizer tokenizer = new Tokenizer(msg,"@");
      //  String idc = tokenizer.nextToken();

        String skey="";
        String plaintext = "";
        skey = DES_Method.PasswdtoDES(password);
        keys = DES_Method.Produce_keys(skey);
        String dekeys[]=new String[16];
        for(int i=0;i<16;i++){
            dekeys[i]=keys[15-i];
        }

        try {
            plaintext = DES_Method.DES_dencry(msg,dekeys);
        }catch (Exception e){
            e.printStackTrace();
        }
        plaintext=plaintext.trim();
        if (plaintext.equals("账号或密码错误")||plaintext.equals("已经注册")||plaintext.equals("失败")||plaintext.equals("注册成功"))
        {
            return plaintext;
        }

        String idc = username;
        String idtgs = "tgs";
        String ts1 = DateToString.CurrentDate();
        String responde = idc+"@"+idtgs+"@"+ts1;
        return "00000100"+responde;
    };      //确认注册信息，发送c_as包

    public String C_Process_4(String msg,String address){
        String plaintext = "";
        String RES = "";
        String dekeys[]=new String[16];
        for(int i=0;i<16;i++){
            dekeys[i]=keys[15-i];
        }

        try {
            plaintext = DES_Method.DES_dencry(msg,dekeys);
        }catch (Exception e){
            e.printStackTrace();
        }

    Tokenizer tokenizer = new Tokenizer(plaintext,"@");
     Kctgs = tokenizer.nextToken();
     String idtgs=tokenizer.nextToken();
    String ts2 = tokenizer.nextToken();
    String lifetime = tokenizer.nextToken();
     tickettgs = tokenizer.nextToken();
     System.out.println("ticktgs"+tickettgs);
    try{
        InetAddress ip = InetAddress.getLocalHost();
        String ts3 = DateToString.CurrentDate();
        //拆as_c包
        String idv = "server";
        String temp = username+"@"+ip.getHostAddress().toString()+"@"+ts3;
        String Authenticator = "";
        try {
            String[] Ktgs = DES_Method.Produce_keys(ktgs);
            Authenticator = DES_Method.DES_encry(temp,Ktgs);
        }catch (Exception e){
            e.printStackTrace();
        }
       RES =  idv+"@"+tickettgs+"@"+Authenticator;


    }catch (Exception e){
        e.printStackTrace();
    }
    return RES;
}


  //  public String Store(String id, String pkey){;};   //存储AS的公钥
}

