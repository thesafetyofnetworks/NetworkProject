package AS;

import javax.swing.*;
import java.net.Socket;
import java.util.Scanner;

/**
 * 客户端
 * @author Administrator
 *
 */
public class Client {

    private int port = 9000;
    private String ip="192.168.43.204";
    String username;
    String password;
    String type;
    private static Socket socket;
    private JTextField textField2;
    private String cliName;
    public Client(String us,String pa,String ty,JTextField t){
        try {
            init();
            username=us;
            password=pa;
            type = ty;
            textField2=t;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void init() throws Exception {

        System.out.println("-----客户端已开启-----");
        System.out.println("请输入客户端名字：");
//        Scanner sc = new Scanner(System.in);
//        cliName = sc.next();
        cliName = "client1";
        socket = new Socket(ip,port);
    }

    public void hands() throws Exception{
        Thread threadReader = new Thread(new ThreadReader(socket.getInputStream(),socket.getOutputStream(),username,password,type,textField2),Thread.currentThread().getName());
   //     Thread threadWriter = new Thread(new ThreadWriter(socket.getOutputStream()));
   //     threadWriter.setName(cliName);
   //     threadWriter.start();
        threadReader.start();

    }

    public static void main(String[] args) throws Exception  {
      //  Client client = new Client();
    //    client.hands();
     //   String as_req = "1011002102";
      //  int number = Integer.valueOf(as_req.substring(0,4),2);
      //  String msg = as_req.substring(4,as_req.length());
      //  System.out.println(msg);
      //  Signiture signiture = new Signiture();
      //  signiture.thwrite(socket);

    }

}