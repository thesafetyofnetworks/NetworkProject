package AS;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import DES.DES_Method;

import javax.swing.*;

/**
 * 读取输入流线程
 * @author Administrator
 *
 */
public class ThreadReader implements Runnable{
    //private static int HEAD_SIZE=5;//传输最大字节长度
    //private static int BUFFER_SIZE=10;//每次读取10个字节
    private InputStream is;
    private OutputStream os;
    String username;
    String password;
    String type;
    private JTextField textField2;
    public ThreadReader(InputStream is,OutputStream os,String user,String pass,String ty,JTextField t) {
        this.is = is;
        this.os = os;
        username=user;
        password=pass;
        type = ty;
        textField2=t;
    }

    @Override
    public void run() {

        try {
            listener listener = new listener(username,password,type);
            String message = listener.C_Process_1();//发起认证请求
            os.write(message.getBytes());
            os.flush();
            String address="";
            while(true) {
                message="";
                byte[] b = new byte[20480];
                int length = is.read(b);
                message += new String(b, 0, length);
                System.out.println("获取到加密信息：" + message);
                String M = message;
                int number = Integer.valueOf(message.substring(0, 8), 2);
                System.out.println("这是数字"+number+"的进程");
                String responde = listener.Client(M,address);
                if(responde.equals(null))
                    break;
                if(responde.equals("账号或密码错误")||responde.equals("已经注册")||responde.equals("失败")||responde.equals("注册成功"))
                {
                    textField2.setText(responde);
                    break;
                }
              //  String responde = "00000001AS@65537@54585602415110048122234176038590113655681591112768743307823404963188670582797948499162220356048686769767021771475388184683993658039379571992233528318148282746487548656622183959328206983779652251331239790112174140358629454811306042518744614321361200981399576183728967194939768827113217013788973940183694793627938677740768718527475218080563963039613051635136121946670974779661733978231982274741595877070209788408409258828599678691751214118716044668622570640490487190379483004763802435294741319540473636400046767773465321554500362643856626697667180749387622730283539808059278696250047540297597870808080747555388824561369";
                System.out.println("返回的报文是" + responde);
                os.write(responde.getBytes());
                os.flush();
            }
            }
        catch (IOException e) {
            e.printStackTrace();
        }

    }

}