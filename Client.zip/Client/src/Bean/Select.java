package Bean;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Select {
    public static String select_Pk(String id){ String pd="";
    try{
        DBConn con = new DBConn();
        Connection conn = con.getConn();
        Statement st = conn.createStatement();
        ResultSet rs = null;
	 String sql = "SELECT *  FROM kkeys WHERE c_id='"+id+"'";
     rs = st.executeQuery(sql);
        //Security md=new Security();
     while(rs.next()){

           pd = rs.getString("pKey");
          System.out.println(pd);
        /*  String  y=md.md5Password("woma");
         System.out.print( pd+"\n"  );
         System.out.print(y+"\n");
         if(pd.equals(y))
        	 System.out.print("ok"+"\n");
     */
     }
     rs.close();
     st.close();
     conn.close();
 }catch(SQLException se){

    se.printStackTrace();
}catch(Exception e){
    e.printStackTrace();
}
    return pd;
}
public static void main(String []args){
    select_Pk("znclient");
}
}
