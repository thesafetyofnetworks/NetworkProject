package Bean;

import java.sql.*;
import java.util.ArrayList;

public class Select {
    public static ArrayList<String> LoadMessage() {
        ArrayList<String> m = new ArrayList<>();
        try {
            DBConn con = new DBConn();
            Connection conn = con.getConn();
            Statement st = conn.createStatement();
            ResultSet rs = null;
            String sql = "SELECT user_id  FROM online WHERE sign='" + 1 + "'";
            rs = st.executeQuery(sql);
            //Security md=new Security();
            while (rs.next()) {

                String pd = rs.getString("user_id");
                m.add(pd);
        /*  String  y=md.md5Password("woma");
         System.out.print( pd+"\n"  );
         System.out.print(y+"\n");
         if(pd.equals(y))
        	 System.out.print("ok"+"\n");
     */
            }
            rs.close();
            st.close();
            conn.close();
        } catch (SQLException se) {

            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return m;
    }

    public static boolean UpdateState(String test_name) {
        try {
            DBConn con = new DBConn();
            Connection conn = con.getConn();
            Statement st = conn.createStatement();
            ResultSet rs = null;
            String sql = "UPDATE zz SET ma=? WHERE ma='" + test_name + "'";// AND Student_id='"+stu_id+"';
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "0");
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
