package Bean;

import java.sql.*;

public class Score {
    private String stu_id;
    private String test_id;
    private String test_name;
    private int grade;
    private String stu_class;
    private String stu_name;


    public boolean UpdateState(String test_name){
        try {
    DBConn con = new DBConn();
    Connection conn = con.getConn();
    Statement st = conn.createStatement();
    ResultSet rs = null;
    String sql = "UPDATE zz SET ma=? WHERE ma='"+test_name+"'";// AND Student_id='"+stu_id+"';
            PreparedStatement ps =conn.prepareStatement(sql);
           ps.setString(1,"0");
           ps.executeUpdate();
           ps.close();
           return true;
}       catch (SQLException e){
            e.printStackTrace();
            return false;
        }
    }
}
