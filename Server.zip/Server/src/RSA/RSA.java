package RSA;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.util.Random;

public class RSA {
    private static final int ORDER =2048/2;// 随机数的数量级
    private static final BigInteger two =new BigInteger("2");
    private static final BigInteger one =new BigInteger("1");
    public static BigInteger[] getkey(){
        BigInteger[]keys=new BigInteger[3];
        Random rnd = new Random();
        long startTime = System.currentTimeMillis();
        BigInteger temp=BigInteger.probablePrime(ORDER,rnd);
        BigInteger p= temp.multiply(two).add(one);                       //得到p
        while(!MR.isPrime(p)){
            temp=BigInteger.probablePrime(ORDER,rnd);
            p= temp.multiply(two).add(one);
        }
        temp=BigInteger.probablePrime(ORDER,rnd);
        BigInteger q= temp.multiply(two).add(one);                        //得到q
        while(!MR.isPrime(q)){
            temp=BigInteger.probablePrime(ORDER,rnd);
            q= temp.multiply(two).add(one);
        }
        BigInteger n=p.multiply(q);                                          //得到n
        System.out.println("p:"+p);
        System.out.println("q:"+q);
        BigInteger Fn=(p.subtract(one)).multiply(q.subtract(one));             //得到欧拉函数值Fn
        System.out.println("Fn : "+Fn.toString());
        BigInteger e=BigInteger.valueOf(65537);
        if(Fn.gcd(e)!=BigInteger.valueOf(1))
        MR.getgcd(Fn);                                      //获取到e
        BigInteger d= MR.Egcd(Fn,e);                          //获取到d
        if(d.compareTo(BigInteger.ZERO)<0){
            d=d.add(Fn);                          //获取到d
        }
        System.out.println("e :"+e);
        System.out.println("d :"+d);
        System.out.println("n :"+n.toString());
        System.out.println("生成参数正确性验证：");
        System.out.println("gcd(Fn,e)="+(Fn.gcd(e)));
        System.out.println("d*e mod fn="+(d.multiply(e)).mod(Fn));
        keys[0]=e;
        keys[1]=d;
        keys[2]=n;
        return keys;
    }
    private static String charTobyte(String a){
        int value=0;
        String c=""; String bs="";
        int size=a.length();
        for(int i=0;i<size;i++){
            value = 1 << 8 | a.charAt(i);              //10进制转为长度为4的2进制字符串
            bs = Integer.toBinaryString(value);
            c += bs.substring(1);
        }
        return c;
    }
    private static String byteTochar(String a){
        int value=0;
        String c="";
        int b=0;
        int size=a.length()/8;
        for(int i=0;i<size;i++){
            b=(Integer.parseInt(a.substring(i*8,(i+1)*8),2));
            c+= String.valueOf((char)b);
        }
        return c;
    }
    public static String RSA_encry(String Message,String Pk,String n) throws UnsupportedEncodingException {
      //  final Base64.Encoder encoder = Base64.getEncoder();
     //   byte[] textByte = Message.getBytes("UTF-8");
     //   Message= encoder.encodeToString(textByte);
        Message="11"+charTobyte(Message);
        BigInteger M=new BigInteger(Message);
           BigInteger P=new BigInteger(Pk);
            BigInteger N=new BigInteger(n);
            BigInteger C=M.modPow(P,N);
            return C.toString();
            }
    public static String RSA_dencry(String Message,String Pk,String n) throws UnsupportedEncodingException {
      //  final Base64.Decoder decoder = Base64.getDecoder();
        BigInteger C=new BigInteger(Message);
        BigInteger D=new BigInteger(Pk);
        BigInteger N=new BigInteger(n);
        BigInteger M=C.modPow(D,N);
        String  Mo=byteTochar(M.toString().substring(2));
        return Mo;//new String(decoder.decode(Mo), "UTF-8");
    }
    public static String signature(String Message,String d,String n) throws UnsupportedEncodingException {          //生成签名
        String H= Security.md5digest(Message);   //先获取摘要信息
        String sign=RSA_encry(H,d,n);
        return sign;
    }
    public static boolean verifysign(String sign,String Message, String e, String n) throws UnsupportedEncodingException {          //验证签名
        String H = Security.md5digest(Message);   //先获取摘要信息
        String sign1=RSA_dencry(sign,e,n);         //将解密后的签名与摘要比较
        if(sign1.equals(H))
            return true;
        else
            return false;
    }
    public static boolean verifycert (String ID,String Pk,String sign) throws UnsupportedEncodingException {
        String e="";
        String n="";
        String get= Security.md5digest(ID+"@"+Pk);
        String C=RSA_dencry(sign,e,n);
        if(get.equals(C))
        return true;
        else
            return false;
    }
    public static void main(String[] args) throws UnsupportedEncodingException{
      //  MR.Square_and_Mutiply(BigInteger.valueOf(5),3,BigInteger.valueOf(33));
         long startTime = System.currentTimeMillis();
        BigInteger []keys=getkey();
     /*   String keys[]={"65537",
        "29661978101062211327603120546596727308540038517158753916436744448998857522699899902355374117520818498431617961572134815770497064921440174212420657704719697170310833121874450117392548259965283055780085183106716170416587130539924654656454399039117390947870410708929913006597646935929062934099313806426322881508996960564311548495647507706696719579841412013637126760201557863439941864414151697045355654188308232116572806758604980322890543238128589656621666457164496142153677432942269849359208736667803762137112697732803118603999247442770677140371570498259177931478679957412823338639460370690045022662207346094311033480677",
                "54585602415110048122234176038590113655681591112768743307823404963188670582797948499162220356048686769767021771475388184683993658039379571992233528318148282746487548656622183959328206983779652251331239790112174140358629454811306042518744614321361200981399576183728967194939768827113217013788973940183694793627938677740768718527475218080563963039613051635136121946670974779661733978231982274741595877070209788408409258828599678691751214118716044668622570640490487190379483004763802435294741319540473636400046767773465321554500362643856626697667180749387622730283539808059278696250047540297597870808080747555388824561369"
        };*/
        String M="didifsaaaaaaaaaaaaaaaasffasffsasfasffs";
    //    String H= Security.md5digest(M);
   //     System.out.println(H);
        String sign=signature(M,keys[1].toString(),keys[2].toString());
        System.out.println(verifysign(sign,M,keys[0].toString(),keys[2].toString()));
        //String M="0011nznxnzyqwuyeuqweuywequweyqwyeuqwyeuqyweq13130011yeuqwyeuqyweq131313130011";
     //   BigInteger a=new BigInteger(keys[2]);
       // String v=a.toString(2);

       String C=RSA_encry(M,keys[0].toString(),keys[2].toString());
      //  BigInteger M=new BigInteger("65546848646848444615313213213215165169999999999999999999999785653657520563467735121515155");
       System.out.println("原始密文加密为"+C);
        System.out.println("    密文解密为"+RSA_dencry(C,keys[1].toString(),keys[2].toString()));//BigInteger.valueOf(1019),BigInteger.valueOf(3337)));
        long endTime1 = System.currentTimeMillis();
        System.out.println("运行时间:" + (endTime1 - startTime) + "ms");
    }
}
