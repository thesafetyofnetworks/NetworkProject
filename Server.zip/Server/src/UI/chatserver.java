package UI;

import Bean.Select;
import DES.DES_Method;
import RSA.RSA;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class chatserver {
    public static Logger log = Logger.getLogger(UI.chatserver.class.getClass());
    private JPanel panel1;
    private JButton sendButton;
    private JTextArea textArea1;
    private JList list1;
    private JTextArea textArea2;
    private int times=0;
    private String TGS_V="0101011101011001010100010100111101001000010101010101101001001000";        //TGS v共享密钥
    private String V_d="40620975511514444922216285965739074629524184209666903468575486745552599706507784118145004534381937373448303494370104583725179040809461031140361397169364216206182702478302552457752232388013462323111474276311493655819732530771154778217638276135353729518041167676539262098111833771374171700799479320568389301993297104947547714917814197345395171771611427705037391756390954340231730770007928922629471679046514368238665767386989689956865849678237616087874456195592424076806725136595579516285118648876756543668700742013877914742513465845836770843332905741740787215743834430682237399393060248898270517497002280887998813919793";
    private String V_e="65537";         //自己填
    private String V_n="63718929442271952533922659964974670512090149845594539315941399589355689970449991568953306897314241973281030782923253808128220650970072943940781830691446209609971176934430693643458785400029638110812749871867552889455668043780497144567959782266220138138436189708409612736332102677705818352209082724559371222708377261301490747107220542349665376136509629788771633366449328510967133327832882202643290712782634315826970578578407451775165146357891890096690172664371421017982988978546098246551670703278409622714758569396591397546768678052883661472887556073799960978796135376937443662021273963924847864865257049430817697401453";
    ConcurrentHashMap<String, ClientThread> clientThreads;
    String ToTargetName  = "ALL";//信息发送的目标用户昵称
    DefaultListModel<String> OnlineClientNickName;//在线用户昵称，向其中插入数据，自动将数据插入到JList中
    Map<String,String[]> Keys=new HashMap<>();
    Map<String,String[]> Dekeys=new HashMap<>();;
    ServerSocket serverSocket;//服务器的socket类型为 ServerSocket
    //这里必须要把serverThread线程在外部声明，否则会出现找不到类的报错

    //1.3 线程相关
    ServerThread1 serverThread;//服务器线程：这里的命名增加了1，怀疑系统中有和他同名的类
    //ConcurrentHashMap对于多线程可以不一次死锁掉全部线程
    private JFrame chatserver;

    public chatserver() {
        OnlineClientNickName  =  new DefaultListModel<String>();
        list1.setModel(OnlineClientNickName);
        StartServer();
        AddActionListener();
    }

    private void AddActionListener() {
        sendButton.addActionListener(new ActionListener() {//发送消息
            public void actionPerformed(ActionEvent e) {
                String message = textArea1.getText();
                try {
                    if ("11111111".equals(ToTargetName)) {
                        for (ConcurrentHashMap.Entry<String, ClientThread> entry : clientThreads.entrySet()) {
                            entry.getValue().SendMessage("00010001@" + ToTargetName + "@SERVER@" + message);
                        }
                    } else {
                        clientThreads.get(ToTargetName).SendMessage("MESSAGE@" + ToTargetName + "@SERVER@" + message);
                    }
                }catch(Exception L){

                }
            }
        });
        list1.addListSelectionListener(new ListSelectionListener() { //检验目标发送者是谁
            @Override
            public void valueChanged(ListSelectionEvent e) {
                // TODO Auto-generated method stub
                int index = list1.getSelectedIndex();
                if(index<0) {
                    Error("Server：消息目标用户下标错误");
                    return;
                }
                if(index == 0) {
                    ToTargetName = "11111111";
                }else {
                    String ToClientNickName = (String)OnlineClientNickName.getElementAt(index);
                    ToTargetName = ToClientNickName;
                }
                Success("成功修改消息目标用户为："+ToTargetName);
            }

        });
    }
    private void loadMember(){
        ArrayList<String> m= Select.LoadMessage();
        OnlineClientNickName.removeAllElements();
        OnlineClientNickName.addElement("ALL");
        for (String temp:m
        ) {
            OnlineClientNickName.addElement(temp);
        }
    }
    public void StartServer() {
        int ServerPort = 9002;
        try {
            //3.1.1 对相应端口建立socket
            serverSocket = new ServerSocket(ServerPort);
            //3.1.2 为服务器建立新的线程，在线程里面对socket进行监听
            serverThread = new ServerThread1();//如果不重新建立线程会导致服务器界面阻塞，无法点击
            //3.1.3新建存取每个客户端socket线程的map
            clientThreads = new ConcurrentHashMap<String, ClientThread>();
            //3.1.4 服务端在线用户列表显示ALL
            loadMember();
            // OnlineClientNickName.addElement("ALL");
        } catch (BindException e) {
            // TODO Auto-generated catch block
            Error("Server：端口异常"+e.getMessage());
        } catch(Exception e) {
            Error("Server：服务器启动失败");
        }
        Success("成功运行服务器");
    }
    private class ServerThread1 implements Runnable {//在serverScoket.accept()的时候防止界面死锁
        //5.1 isRuning为true时，服务器不停的accept下一个连接
        boolean isRuning = true;
        //5.1构造函数
        public ServerThread1() {
            new Thread(this).start();
        }
        @Override
        //5.2线程开始后自动运行
        public void run() {
            //5.2.1 循环accept下一个socket连接
            while(isRuning) {
                if(!serverSocket.isClosed()) {
                    try {
                        Socket socket = serverSocket.accept();//这里要为每个即将连接的客户端新建一个socket，注：必须在try内部声明socket
                        ClientThread clientThread = new ClientThread(socket);//每接收到一个服务器请求，就为其新建一个客户线程
                        String ClientNickName = clientThread.getClientNickName();
                        clientThreads.put(ClientNickName, clientThread);//将每个客户端的线程都存在ConcurrentHashMap中
                        Success("为用户"+ClientNickName+"新建线程完毕");
                    } catch (IOException e) {
                        Error("Server：建立客户线程失败"+e.getMessage());
                    }
                }else {
                    Error("Server:服务器socket已关闭");
                }
            }
        }
    }
    public class ClientThread implements Runnable {//为每个客户端建立线程，并存在ConcurrentHashMap中，建立新的线程可防止等待用户输入时死锁
        //6.1 与该用户的socket相关输入输出
        private Socket socket;
        private BufferedReader input;
        private PrintStream output;
        //6.2 由于服务器主线程需要以客户端姓名为key，故需要调用getClientNickName()返回昵称
        private String ClientNickName;

        //6.3用于区分第一次连接和之后接收的消息
        boolean isRuning = false;

        //6.4 构造函数
        public ClientThread(Socket clientSocket) {
            this.socket = clientSocket;
            isRuning = Initialize();
            new Thread(this).start();
        }
        //6.5 第一次生成线程时（用户刚登陆时）调用
        public synchronized boolean Initialize() {
            try {
                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                output = new PrintStream(socket.getOutputStream());
                //6.5.1 接收用户的输入数据
                String message;
                message = input.readLine();//readline运行时阻塞，故须建立客户端线程
                System.out.println(message);
                //6.5.2 检验信息头是否为ShowMessageIN，是则向所有其他用户转发
                /*try {
                    clientInputStr = Message(clientInputStr);
                }catch (Exception L){
                    ShowMessage("加密解密错误");
                }
                Tokenizer tokens = new Tokenizer(clientInputStr,"@");
                String MessageType = tokens.nextToken();
               */
                //   String date=DateToString.CurrentDate();
                int number = Integer.valueOf(message.substring(0,8),2);
                message=message.substring(8);
                if(number==8) {
                    Tokenizer token = new Tokenizer(message, "@");//对原有消息进行分割
                    String Ticketv = token.nextToken();
                    String de[]=DES_Method.Produce_keys(TGS_V);
                    String dekeys[]=new String[16];
                    for(int i=0;i<16;i++){
                        dekeys[i]=de[15-i];
                    }
                    Ticketv=DES_Method.DES_dencry(Ticketv,dekeys);
                    Tokenizer token1 = new Tokenizer(Ticketv, "@");//对原有消息进行分割
                    String Kcv=token1.nextToken();
                    String IDc=token1.nextToken();
                    ClientNickName=IDc;
                    String ADc=token1.nextToken();
                    String IDv=token1.nextToken();
                    String TS4=token1.nextToken();
                    String Lifetime4=token1.nextToken();
                    String ks[]=DES_Method.Produce_keys(Kcv); //会话密钥
                    System.out.println("TS4:"+TS4);
                    Keys.put(IDc,ks);
                    for(int i=0;i<16;i++){
                        dekeys[i]=ks[15-i];
                    }
                    Dekeys.put(IDc,dekeys);
                    String authc = token.nextToken();
                    authc=DES_Method.DES_dencry(authc,dekeys);
                    Tokenizer token2 = new Tokenizer(authc, "@");//对原有消息进行分割
                    String IDc1=token2.nextToken();
                    String ADc1=token2.nextToken();
                    String TS5=token2.nextToken();
                    System.out.println("T5："+TS5);
                    //进行比较比较判断
                    sendCVresponse(TS5,ks);
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                Error("Server：Initialize无法读取下一行 "+e.getMessage());
            }
            Success("用户线程初始化完毕");
            return true;
        }
        @Override
        //6.6 线程开始时自动调用该方法
        public void run() {
            while(isRuning) {String clientInputStr="";
                try {
                    //6.6.1接收用户的输入数据
                  /*  clientInputStr = input.readLine();
                    try {
                        clientInputStr = Message(clientInputStr);
                    }catch (Exception L){
                        ShowMessage("加密解密错误");
                    }
                    ShowMessage("Server："+clientInputStr);
                    */
                    clientInputStr = input.readLine();
                    int number = Integer.valueOf(clientInputStr.substring(0,8),2);
                    clientInputStr=clientInputStr.substring(8);
                    System.out.println("11151515");
                    //6.6.2按信息头部分类处理
                    switch(number) {
                        case 13:{               //client上线通知
                            ClientNickName=clientInputStr;
                            //  ClientNickName = tokens.nextToken();
                            OnlineClientNickName.addElement(ClientNickName);//服务端在线用户列表显示该用户昵称
                            System.out.println("broadcast"+ClientNickName+"login");
                            BroadcastLogin("00010010"+ClientNickName+"@"+RSA.signature(ClientNickName,V_d,V_n),ClientNickName);//向所有已登陆用户广播该用户登陆的信息
                            break;
                        }
                        case 14:{
                            System.out.println("11151515"+clientInputStr);
                            Tokenizer tokens = new Tokenizer(clientInputStr,"@");
                            String ID_send = tokens.nextToken();
                            String ID_rec = tokens.nextToken();
                            String sessionkey= tokens.nextToken();
                            String dekeys[]=Dekeys.get(ID_send);
                            sessionkey=DES_Method.Encry(sessionkey,dekeys);
                            //   String sess[]=DES_Method.Produce_keys(sessionkey);
                            String smess=sendpack14("00001110"+ID_send+"@"+ID_rec+"@",sessionkey,Keys.get(ID_rec));
                            clientThreads.get(ID_rec).SendBroad(smess);
                            break;
                        }
                        case 15:{
                            Tokenizer tokens = new Tokenizer(clientInputStr,"@");
                            String ID_send = tokens.nextToken();
                            String ID_rec = tokens.nextToken();
                            String message = tokens.nextToken();
                            String dekeys[]=Dekeys.get(ID_send);
                            message=DES_Method.DES_dencry(message,dekeys);
                            //   String sess[]=DES_Method.Produce_keys(sessionkey);
                            String smess=sendpack15("00001111"+ID_send+"@"+ID_rec+"@",message,Keys.get(ID_rec));
                            clientThreads.get(ID_rec).SendBroad(smess);
                            break;
                        }
                        case 16:{//私聊消息
                            Tokenizer tokens = new Tokenizer(clientInputStr,"@");
                            System.out.println("收到私聊消息"+clientInputStr);
                            String secd = tokens.nextToken();       //接收端
                            String ToClientNickName=tokens.nextToken();
                            //对消息进行一对一的转发
                            try{
                                clientThreads.get(ToClientNickName).SendBroad("00010000"+clientInputStr);
                                ShowMessage("Server: 已将来自"+secd+"的消息"+"00010000"+clientInputStr+"转发给"+ToClientNickName);
                            }catch (Exception L){

                            }
                            break;
                        }
                        case 17:{//广播消息
                            Tokenizer tokens = new Tokenizer(clientInputStr,"@");
                            String send = tokens.nextToken();
                            //对消息进行广播转发
                            // Broadcast(clientInputStr);
                            String message=tokens.nextToken();
                            String signa=tokens.nextToken();
                            String m="来自"+send+"发来的消息消息内容为"+message+"签名为"+signa;
                            System.out.println(m);
                            Broadcast("00010001"+clientInputStr);
                            // Broadcast("来自"+send+"发来的消息消息内容为"+tokens.nextToken());
                            ShowMessage(m);
                            break;
                        }
                        default : {
                            //Select.UpdateState(clientInputStr);
                            //  loadMember();
                            Tokenizer tokens = new Tokenizer(clientInputStr,"@");
                            Broadcast(clientInputStr);
                            ShowMessage("Server：用户"+tokens.nextToken()+"退出");
                            Error("Server: 服务器收到的消息格式错误");
                            break;
                        }
                    }
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    //Select.UpdateState(clientInputStr);
                    // loadMember();
                    Error("client：断开连接 "+e.getMessage());
                    break;
                }
            }

        }

        //6.7 返回该用户昵称
        public String getClientNickName() {
            return ClientNickName;
        }
        public void sendCVresponse(String TS5,String[]keys){
            TS5=TS5.substring(0,13)+String.valueOf((Integer.valueOf(TS5.substring(13,14))+1)).substring(0,1);
            try{
                TS5=DES_Method.DES_encry(TS5,keys);
                System.out.println("TS5+1:"+TS5);
                output.println("00001001"+TS5);
                output.flush();
            }catch (Exception e){

            }
        }
        //6.8 发送消息
        public void SendMessage(String message) throws Exception {
            message=DataCry(message);
            output.println(message);
            output.flush();
        }
        private String DataCry(String message) throws Exception{
            String keys[]= DES_Method.Produce_keys("11111111111111111111111111111111111111111111111111111000");
            String C= DES_Method.DES_encry(message,keys);
            message=("原文"+message+"  被加密为："+C);
            textArea2.setText(textArea2.getText()+"\n"+message);
            return C;
        }

        public void SendBroad(String message)   {
            output.println(message);
            output.flush();
        }
        //6.9 向全体在线账号发送消息
        public void Broadcast(String Message) {
            for (ConcurrentHashMap.Entry<String, ClientThread> entry : clientThreads.entrySet()) {
                entry.getValue().SendBroad(Message);            //获取client进程
            }

        }
        public String sendpack14(String hea,String key,String Kcv[]){
            try{
                key=DES_Method.Encry(key,Kcv);
                System.out.println("转发消息"+hea+key);
            }catch (Exception e){

            }return hea+key;
        }
        public String sendpack15(String hea,String yes,String Kcv[]){
            try{
                System.out.println("转发信息"+hea+yes);
                yes=DataCry(yes,Kcv);
                System.out.println("转发加密确认信息"+hea+yes);

            }catch (Exception e){

            }  return hea+yes;
        }
        private String DataCry(String message,String keys[]) throws Exception{
            //String keys[]=DES_Method.Produce_keys("11111111111111111111111111111111111111111111111111111000");
            String C= DES_Method.DES_encry(message,keys);
            //  message=("转发私聊请求消息"+message+"加密为："+C);
            //   textArea2.setText(textArea2.getText()+message+"\n");
            return C;
        }
        //6.9 向全体在线账号发送消息同时更新客户端当前用户登陆信息
        public void BroadcastLogin(String Message,String name) {
            try{
                for (ConcurrentHashMap.Entry<String, ClientThread> entry : clientThreads.entrySet()) {
                    if(entry.getValue().getClientNickName().equals(name)){
                        String temp;
                        for (int i=0;i<OnlineClientNickName.getSize();i++)
                        {
                            temp=OnlineClientNickName.get(i);
                            entry.getValue().SendBroad("00010010"+temp+"@"+RSA.signature(temp,V_d,V_n));
                        }
                    }
                    else
                        entry.getValue().SendBroad(Message);
                }
            }catch (Exception L){

            }
        }
    }

    private void ShowMessage(String message){
        //JLabel不支持\n换行，故添加html标签进行换行，没有</html>结束标签不影响显示
        textArea2.setText(textArea2.getText()+"\n"+message);
    }
    //4.4 输出错误信息
    private void Error(String message){
        //JLabel不支持\n换行，故添加html标签进行换行，没有</html>结束标签不影响显示
        textArea2.setText(textArea2.getText()+"\n"+message);
    }
    //4.4 输出成功信息
    private void Success(String message){
        //JLabel不支持\n换行，故添加html标签进行换行，没有</html>结束标签不影响显示
        textArea2.setText(textArea2.getText()+"\n"+message);
    }
    private String  maMessage(String message) throws Exception{
        String keys[]= DES_Method.Produce_keys("11111111111111111111111111111111111111111111111111111000");
        textArea2.setText(textArea2.getText()+"\n"+"信息加密为"+message);
        String dekeys[]=new String[16];
        for(int i=0;i<16;i++){
            dekeys[i]=keys[15-i];
        }
        message=DES_Method.DES_dencry(message,dekeys);
        textArea2.setText(textArea2.getText()+"\n"+"信息解密为"+message);
        return message;
    }
    public class Tokenizer{
        String Tokens[];
        int TokenIndex = 0;
        //7.1 将消息Message按照Delimiter分割
        public Tokenizer(String Message, String Delimiter) {
            Tokens = Message.split(Delimiter);
        }
        //7.2 返回下一个内容
        public String nextToken() {
            TokenIndex++;
            return Tokens[TokenIndex-1];
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("chatserver");
        frame.setContentPane(new chatserver().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
